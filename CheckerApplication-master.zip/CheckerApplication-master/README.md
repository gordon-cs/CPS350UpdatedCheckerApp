# CheckerApplication
Master Application

This is an application for scanning proxIDs for event attendance.
